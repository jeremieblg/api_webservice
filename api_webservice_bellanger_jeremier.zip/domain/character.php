<?php
class Character{

    public $character_id;
    public $first_name;
    public $last_name;
    public $hero_name;
    public $created;
    public $modified;
    
}
?>