<?php
class Power{

    public $power_id;
    public $character_id;
    public $power_name;
    
}
?>